package com.example.demo.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.service.UserInfoService;
import com.example.demo.vo.UserInfoVO;

@Controller
public class UserController {

	@Autowired
	private UserInfoService uiService;

	@PostMapping("/login")
	public String login(@ModelAttribute UserInfoVO userInfoVO, HttpSession session) {
		if (uiService.login(userInfoVO, session)) {
			return "index";
		}
		return "user/login";
	}
}