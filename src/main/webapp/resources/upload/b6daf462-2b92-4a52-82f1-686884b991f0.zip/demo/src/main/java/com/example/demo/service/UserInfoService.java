package com.example.demo.service;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.mapper.UserInfoMapper;
import com.example.demo.vo.UserInfoVO;

@Service
public class UserInfoService {
// interface 서비스, 서비스 구현객체가 정석

	@Autowired
	private UserInfoMapper uiMapper;

	public boolean login(UserInfoVO userInfo, HttpSession session) {
		userInfo = uiMapper.selectUserInfo(userInfo);
		if (userInfo != null) {
			session.setAttribute("user", userInfo);
			return true;
		}
		return false;
	}
}