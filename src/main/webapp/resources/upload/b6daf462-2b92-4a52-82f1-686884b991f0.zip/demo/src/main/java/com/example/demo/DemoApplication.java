package com.example.demo;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

// 자동으로 동작하지 않는 설정(exclude = DataSourceAutoConfiguration.class)
@SpringBootApplication
@MapperScan	// myBatis가 자동으로 UserInfoMapper 메모리를 생성해준다.
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

}