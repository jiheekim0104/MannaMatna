package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller // 스프링에 Controller라고 알려준다.
public class ViewController {
	@GetMapping("/") // /라는 url 요청이 들어왔을 경우 index 로 응답한다.
	public String home() {
		// url, 파일명을 효과적으로 관리하기위한 것은 String
		return "index"; // application.properties의 prefix, suffix 참고
	}

	@GetMapping("/login")
	public String login() {
		return "user/login";
	}

	@GetMapping("/apple")
	public String apple() {
		return "test/t1/apple";
	}

	@GetMapping("/banana")
	public String banana() {
		return "test/t2/banana";
	}
}