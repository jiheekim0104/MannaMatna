package com.example.demo.mapper;

import com.example.demo.vo.UserInfoVO;

public interface UserInfoMapper {
	UserInfoVO selectUserInfo(UserInfoVO userInfo);
}