
public class Test {

	public void eat(int water, String rice, String fruit) {

	}

	public int cookWater() {
		return 1;
	}

	public String cookRice() {
		return "쌀밥";
	}

	public String cookFruit() {
		return "사과";
	}

	public static void main(String[] args) {
		Test t = new Test();
		t.eat(0, null, null);
	}
}
class Menu{
	int water;
	String rice;
	String fruit;
}